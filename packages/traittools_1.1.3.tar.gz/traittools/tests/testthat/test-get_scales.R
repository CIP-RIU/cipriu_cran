context("Get traits scales")

test_that("get traits from HIDAP files ", {
  
  library(traittools)
  library(fbdesign) #import datasets
  library(readxl)
  fb <- read_xlsx(test_sheet("get_traits_ptAbioticStress_Issues266.xlsx"),sheet = "Fieldbook")
  fb <- as.data.frame(fb, stringsAsFactors=FALSE) 
  traits<- get_trait_fb(fieldbook = fb, dsource = 1)
  trait_dict <- get_crop_ontology(crop = "potato", dsource = 1)
  validator <- lapply(traits, function(x) v <- get_scale_trait(trait = traits, trait_dict = trait_dict, dsource = 1))
  #expect_identical(traits, expected_traits)
  
})









