#'Calculation of Average of days after planting Evaluation
#'
#'@param ... Day after planting evaluations 
#'@return dap_av
#'@description This functions calculate the Average of days after planting Evaluation
#'@author Omar Benites
#'@references Procedures for standard evaluation and data management of advanced potato clones: Assessment of Abiotic stress.International Potato Center (CIP).
#'@family abiotic stress, potato
#'@export


dap_av <- function(...){
 
    res <- dplyr::data_frame(...)
    dap_av <- rowMeans(res, na.rm = TRUE)
    #avdm <- apply(cbind(dm1,dm2),1,sbsum)/2
     
  return(dap_av)
}


#'Calculation of Average of plant height Evaluation
#'
#'@param ... plant height Evaluations 
#'@return plahe_av
#'@description This functions calculate the Average of plant height Evaluation
#'@author Omar Benites
#'@references Procedures for standard evaluation and data management of advanced potato clones: Assessment of Abiotic stress.International Potato Center (CIP).
#'@family abiotic stress, potato
#'@export


plahe_av <- function(...){
  
  res <- dplyr::data_frame(...)
  plahe_av <- rowMeans(res, na.rm = TRUE)
  #avdm <- apply(cbind(dm1,dm2),1,sbsum)/2
  
  return(plahe_av)
}



#'Calculation of Average of trait evalutions in diferent periods of time
#'
#'@param ... trait evalutions in diferent times
#'@return plahe_av
#'@description This functions calculate the trait Average in diferent times
#'@author Omar Benites
#'@references Procedures for standard evaluation and data management of advanced potato clones: Assessment of Abiotic stress.International Potato Center (CIP).
#'@family abiotic stress, potato
#'@export


traitEv_av <- function(...){
  
  res <- dplyr::data_frame(...)
  traitEv_av  <- rowMeans(res, na.rm = TRUE)
  #avdm <- apply(cbind(dm1,dm2),1,sbsum)/2
  
  return(traitEv_av)
}

#'Calculation of Specific leaf area Evaluation Physiological traits	
#'@param lfa_ev leaf area evaluation
#'@param lealflet_dw leaflet dry weight
#'@return sla_ev
#'@description This functions calculate the trait Average in diferent times
#'@author Omar Benites
#'@references Procedures for standard evaluation and data management of advanced potato clones: Assessment of Abiotic stress.International Potato Center (CIP).
#'@family abiotic stress, potato
#'@export

sla_ev <- function(lfa_ev, lealflet_dw){

  sla_ev <- (lfa_ev/ lealflet_dw)
  return(sla_ev)
  
}



#'Calculation of Canopy temperature depression (CTD)
#'@param Ta atmopheric temperature
#'@param Tc canopy temperature
#'@return ctd
#'@description This functions calculate the trait Average in diferent times
#'@author Omar Benites
#'@references Procedures for standard evaluation and data management of advanced potato clones: Assessment of Abiotic stress.International Potato Center (CIP).
#'@family abiotic stress, potato
#'@export

ctd <- function(Ta, Tc){
  
  sla_ev <- Ta- Tc
  return(sla_ev)
  
}



