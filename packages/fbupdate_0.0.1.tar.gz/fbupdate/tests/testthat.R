library(testthat)
library(fbupdate)

test_check("fbupdate")
