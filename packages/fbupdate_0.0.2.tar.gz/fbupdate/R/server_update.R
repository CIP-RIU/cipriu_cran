#' Server component for traittools in fbcheck
#'
#' Returns server side components
#' @author Omar Benites
#' @param input shinyserver input
#' @param output nameo of the output element
#' @param session shinyserver session
#' @param values The reactive values
#' @importFrom remotes install_url
#' @importFrom dplyr filter
#' @importFrom shiny req withProgress incProgress reactive
#' @importFrom shinyjs extendShinyjs
#' @importFrom rhandsontable rhandsontable
#' @importFrom curl has_internet
#' @export

fbupdate_server <- function(input, output, session, values) {
  
  #Catch the file path for reading fieldbook sheets
  # volumes <- shinyFiles::getVolumes()
  # shinyFileChoose(input, 'file', roots=volumes, session=session,
  #                 restrictions=system.file(package='base'),filetypes=c('xlsx'))
  
  Package <- Version <- NULL
  
  
  #Reactive table for cross-checking packages
  dtpkg <- reactive({
    
    #left_join(user,riu, by= c("Package", "Version"))
    
    riu <- get_cipriutable_github()
    user <- get_user_pkgs() 
    
    #filter identical packages which are in the cloud 
    #res <- filter(.data = user, Package %in% riu$Package)
    res <- filter(.data = user, Package %in% riu$Package)
    #filter which version is out-of-date
    update_pkgs <- filter(riu, Version > res$Version)
    
    #packges which are in github but not in the user's computer
    up2 <- filter(riu, res$Package!=riu$Package)
    
    #row bind of packages
    update_pkgs <- rbind(update_pkgs,up2)
    
    update_pkgs
    
  })


# Check package in the github server (for updating) -----------------------

  output$hot_table_checkpkg  <-  renderRHandsontable({
    
    req(input$fbupdate_btnCheck)
    
    
    # riu <- get_cipriutable_github()
    # user <- get_user_pkgs() 
    # 
    # #filter identical packages which are in the cloud 
    # res <- filter(.data = user, Package == riu$Package)
    # #filter which version is out-of-date
    # update_pkgs <- filter(riu, Version > res$Version)
    
    withProgress(message = 'Checking for updates', value = 0, {
    
      incProgress(1/3, detail = paste("Checking for updates"))  
      
      update_pkgs <- dtpkg()
      
      incProgress(2/3, detail = paste("Loading updates")) 
      
      if(nrow(update_pkgs)==0){  update_pkgs <- data.frame(Packages ="There are no packages for updating")}
      rhandsontable(data = update_pkgs, height = 780)
      
    
    })
   
  })

  
  # Update packages ---------------------------------------------------------
  
  shiny::observeEvent( input$fbupdate_btnUpdate, {
    
    url <- dtpkg()$url
    pkg <- dtpkg()$Package
    lib_pkg <- fbupdate::get_package_dir() #the directory where the updated packages will be stored. If the package exists, it will overwrite them.
    
    print(url)
    print(pkg)
    
    r_version <- getRversion() %>% as.character()
    
    withProgress(message = 'Update', value = 0, {
      
      if(length(url)==0){ #check if exist 
        #flag <- FALSE
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("ERROR: There are no packages for updating"), styleclass = "warning")
      } else if(!curl::has_internet()){ #check internet connection
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("There is no internet connection. Check your connection"), styleclass = "danger")
      
      } else if(r_version<="3.3.0"){
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("ERROR: Your have an older version of R" , r_version ," .At least you requiere the R 3.3.1 version"), styleclass = "danger")
        
      } else {
        
        n <- length(url)
        for(i in 1:n){
        
          #incProgress(1/n, detail = paste("Installing packages ", url[i]))
          incProgress(1/n, detail = paste("Installing package ", pkg[i]))
            #remotes::install_url(url[i], dependencies= FALSE)
             remotes::install_url(url[i], dependencies= FALSE, lib = lib_pkg)
        
        }  
        
      }  
      #remotes::install_url("https://cip-riu.github.io/cipriu_cran/packages/traittools_1.0.1.tar.gz", dependencies = FALSE)
      
    })  
    
    
    withProgress(message = 'Refresh', value = 0, {
      

      library(d3heatmap)
      library(shinysky)
      library(data.table)
      library(shinyTree)
      
      library(doBy)
      library(tidyr)
      library(DT)
      library(brapi)
      library(brapps)
      library(agricolae)
      library(openxlsx)
      library(fbmet)
      library(fbhelp)
      library(fbdesign)
      library(rhandsontable)
      library(shinydashboard)
      library(date)
      
      library(purrr)
      library(shinyURL)
      library(qtlcharts)
      library(leaflet)
      library(withr)
      library(dplyr)
      library(st4gi)
      library(tibble)
      library(knitr)
      library(readxl)
      library(countrycode)
      library(fbsites)
      library(fbmlist)
      library(fbmet)
      
      library(fbcheck)
      library(fbmlist)
      library(countrycode)
      library(shinyjs)
      library(DBI)
      library(RMySQL)
      library(spsurvey)
      library(foreign)
      library(tools)
      library(stringr)
      library(shinyBS)
      library(fbdesign)
      library(fbopenbooks)
      library(fbanalysis)
      library(traittools)
      library(sbformula)
      library(pepa)
      library(shinyFiles)
      library(rlist)
      library(rprojroot)
      library(factoextra)
      library(ggrepel)
      
      library(fbdocs)
      library(geneticdsg)
      
      
      incProgress(10/10, detail = paste("Refreshing Hidap..."))  
      
     
      
      shinyjs::js$refresh()
    })
    
    
    
  }) 
  
  #Refresh Page button
  # observeEvent(input$fbupdate_btnRefresh, {
  #   
  #   withProgress(message = 'Refresh', value = 0, {
  #     
  #     incProgress(2/3, detail = paste("Refreshing Hidap..."))  
  #   
  #     incProgress(3/3, detail = paste("Refreshing Hidap..."))  
  #     
  #   shinyjs::js$refresh()
  #   })
  #   
  # })
  
}



