#' Geometric mean
#'
#'@param x vector
#'@param na.rm whether to remove NA.
#'@description calculate geometric mean of vector.
#'
#'@export

gm_mean <-  function(x, na.rm=TRUE){
  exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
}

#'Function to calculate the Drought Suceptibility Index (DSI) using mean yield values
#'
#'@param trait A data frame with yield means. Included genotypes and Factor.
#'@param geno vector. Genotypes
#'@param dfactor vector. factor name
#'@param clabel The label of controled level. Example: \code{irrigation}, \code{normal irrigation}
#'@param slabel The label of stressed level. Example: \code{stress}, \code{inttermitent}
#'@param fb data.frame. Field data
#'@return The drought suceptible index using means
#'@author Omar Benites
#'@details This function returns the drought suceptible index (DSI) using means.
#'@references Comparison of yield based drought tolerance indices in improved varieties, genetic stocks and landraces
#'of potato \code{Solanum tuberosum L.}
#'@keywords index, drought
#'@family index
#'@export

#DSI <- function(dfmeans,clabel=NA, slabel=NA)
DSI.means <- function(trait, geno = NULL, dfactor = NULL,clabel=NULL, slabel=NULL, fb){

    fb <- fb
   
    stress_lvl <- slabel  #stress_lvl <- input$sel_lvlstress_droindex
    control_lvl <- clabel  #control_lvl <- input$sel_lvlcontrol_droindex
    dfactor <- dfactor
    
    dots_stress  <- paste( dfactor, "=='", stress_lvl,  "'", sep="" ) #subset of stress environment
    dots_control <- paste( dfactor, "=='", control_lvl, "'" , sep="") #subset of nonstress/controled environment
    
    col_mean <- "trait_mean"
    
    mean_y <- paste("mean(", trait,",na.rm=TRUE" ,")", sep="") #summarization using the mean
    fb <- fb %>% 
          group_by_(.dots=c(geno,dfactor)) %>% 
          summarize_(trait_mean = mean_y)
    
    #tabular data for stressed environment 
    stress_val  <- fb %>% filter_(dots_stress)  %>% select_(geno, col_mean) #%>% pull()
    colnames(stress_val)[2] <- "Stress" 
    
    #tabular data for controled environment 
    control_val <- fb %>% filter_(dots_control) %>% select_(geno, col_mean) #%>% pull()
    colnames(control_val)[2] <- "Control" 
    
    fb <- dplyr::left_join(x = stress_val,y = control_val )
    
    Stress <- Control <- NULL
    didt <- fb %>% mutate( SI = 1-(gm_mean(Stress)/gm_mean(Control)),
                         DSI = round((1-(Stress/Control))/(1-(mean(Stress,na.rm = TRUE)/mean(Control,na.rm = TRUE))),2)   , 
                         DTI = round((Stress*Control)/( gm_mean(Control,na.rm = TRUE) )^2,2),
                         TOL = round((Control - Stress),2),
                         MP  = round((Control + Stress)/2,2),
                         GMP = sqrt(Stress*Control)) %>% 
          select(-Stress,-Control)
              
    
    # didt <- data.frame(SI, DSI, DTI, TOL, MP, GMP, TDWS, stringsAsFactors = FALSE) 
    
    return(didt)
}



