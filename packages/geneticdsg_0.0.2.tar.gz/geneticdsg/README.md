# geneticdsg
Package for Genetic Design performed in plant breeding experiments. It includes north caroline design I &amp; II (NCI, NCII), Line by Tester (LXT) and among others.
