library(testthat)
library(bsplus)

test_check("bsplus")
