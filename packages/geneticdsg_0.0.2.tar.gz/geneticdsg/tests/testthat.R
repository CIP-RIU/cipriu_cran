library(testthat)
library(geneticdsg)

test_check("geneticdsg")
