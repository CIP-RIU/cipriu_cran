library(testthat)
library(fbcheck)

test_check("fbcheck")
