library(testthat)
library(fbdesign)

test_check("fbdesign")
