context("infrastructure")
# 
# td <- tempdir()
# unlink(file.path(td, "R"))

test_that("When RIU-CRAN have additional packages than USER", {
  
 user <- data.frame(user=c("a.1.2", "a.2","a.3"), stringsAsFactors = FALSE)
 riucran <- data.frame(riucran = c("a.1.2", "a.2","a.3", "a4"  ) , stringsAsFactors = FALSE) 
  
  
})