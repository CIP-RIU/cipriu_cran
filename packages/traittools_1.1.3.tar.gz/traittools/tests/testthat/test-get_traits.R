context("Get traits")

test_that("get traits from fieldbookApp table format ", {
  
  library(traittools)
  library(readr)
  fb <- read_csv(test_sheet("fbapp_tableFormat_fumesua.csv"))
  names(fb) <- gsub("[[:space:]]", "", names(fb)) #remove whitespaces
  
  traits<- get_trait_fb(fieldbook = fb, dsource = 2)
  
  expected_traits <- c("ALCDAM|CO_331:0000806",  "DMFV|CO_331:0000251", 
                       "MILLDAM|CO_331:0000805", "NOCR|CO_331:0000214",  
                       "NONC|CO_331:0000217",    "NOPE|CO_331:0000192",   
                       "NOPH|CO_331:0000679" ,   "NOPS|CO_331:0000678",    "NOPR|CO_331:0000211",   
                       "RTFSH1|CO_331:0000178",  "RTSKN1|CO_331:0000175",  "WED1|CO_331:0000207",   
                       "RTDEF|CO_331:0000790" ,  "RTSHP|CO_331:0000181",   "DAMR|CO_331:0000206",   
                       "RF|CO_331:0000202",      "RS|CO_331:0000184",      "VV1|CO_331:0000197" ,   
                       "VIR1|CO_331:0000193",    "VIR2|CO_331:2000004",    "CRW|CO_331:0000220" ,   
                       "NCRW|CO_331:0000223",    "VW|CO_331:0000227")

  expect_identical(traits, expected_traits)
  
})


test_that("get traits from HIDAP format ", {
  
  library(traittools)
  library(readxl)
  fb <- read_xlsx(test_sheet("get_traits_ptAbioticStress_Issues266.xlsx"),sheet = "Fieldbook")
  names(fb) <- gsub("[[:space:]]", "", names(fb)) #remove whitespaces
  traits<- get_trait_fb(fieldbook = fb, dsource = 1)
  expected_traits <- c("DAP_EV1"  ,   "DAP_EV2"  ,  
     "DAP_EV3" ,    "DAP_EV4" ,    "DAP_AV"  ,    "PLAHE_EV1"  , "PLAHE_EV2"  , "PLAHE_EV3"  , "PLAHE_EV4"  ,
     "PLAHE_AV" ,   "PLAHE_SLP" ,  "SNPP"    ,    "SD_EV1"   ,   "SD_EV2"  ,    "SD_EV3"    ,  "SD_EV4" ,    
     "SD_AV"   ,    "SD_SLP"  ,    "ChlSPAD_EV1", "ChlSPAD_EV2" ,"ChlSPAD_EV3", "ChlSPAD_EV4", "ChlSPAD_AV", 
     "ChlSPAD_SLP", "DSS"   ,      "PW_EV1"   ,   "PW_EV2",      "NLPP_EV1" ,   "NLPP_EV2"  ,  "NLPP_EV3",   
     "Leaflet_FW1", "Leaflet_FW2", "Leaflet_FW3", "Leaflet_TW1" ,"Leaflet_TW2", "Leaflet_TW3", "Leaflet_DW1",
     "Leaflet_DW2", "Leaflet_DW3","RWC_EV1"  ,   "RWC_EV2"  ,   "RWC_EV3"  ,   "RWC_AV"  ,    "RWC_SLP" ,   
     "LFA_EV1" ,    "LFA_EV2" ,    "LFA_EV3" ,    "SLA_EV1" ,    "SLA_EV2" ,    "SLA_EV3" ,    "SLA_AV"  ,   
     "SLA_SLP" ,    "CC_EV1"  ,    "CC_EV2",      "CC_EV3"  ,    "CC_AV"  ,     "CC_SLP"  ,    "CR_EV1"  ,   
     "CR_EV2" ,     "CR_EV3" ,     "CR_AV" ,      "CR_SLP" ,     "Ta_EV1" ,     "Ta_EV2"  ,    "Ta_EV3"  ,   
     "Tc_EV1"  ,    "Tc_EV2" ,     "Tc_EV3" ,     "CTD_EV1"  ,   "CTD_EV2"  ,   "CTD_EV3" ,    "CTD_AV"  ,   
     "CTD_SLP" ,    "LFW"  ,       "LDW"    ,     "SFW"   ,      "SDW"   ,      "APFW"  ,      "APDW" ,      
     "RFW"  ,       "RDW",         "STLFW"  ,     "STLDW"   ,    "RSFW" ,       "RSDW"  ,      "TFW"   ,     
     "FWTS"  ,      "DWTS" ,       "TDW"   ,      "TBFW",        "TBDW" ,       "HI_FW"  ,     "HI_DW"   ,   
     "Pwi"  ,       "Pwf" ,        "WA"  ,        "WA_total" ,   "ET",          "NBL_EV1"  ,   "NBL_EV2"  ,  
     "NBL_EV3"  ,   "NBL_EV4" ,    "NBL_AV" ,     "NBL_SLP" ,    "NSL_EV1" ,    "NSL_EV2" ,    "NSL_EV3"  ,  
     "NSL_EV4"  ,   "NSL_AV"  ,    "NSL_SLP",     "WUE"  ,       "RD"  ,        "RL"   ,       "ATWP"  ,     
     "GMTTWT" ,     "SI" ,         "DSI"  ,       "DTI" ,        "TOL"  ,       "MP"    ,      "GMP"  ,      
     "LDMCP" ,      "SDMCP",       "APDMCP"  ,    "RDMCP"    ,   "STLDMCP",     "RSDMCP" ,     "TDMCP" ,     
     "TBDMC")
  
  expect_identical(traits, expected_traits)
  
}) 