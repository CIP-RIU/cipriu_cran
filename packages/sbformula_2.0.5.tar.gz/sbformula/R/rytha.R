#'Formula for calculating the Total root yield (RYTHA)
#'
#'@param crw Commercial root weight
#'@param ncrw Non commercial root weight
#'@param pls Net plot size
#'@return Return the Total root yield 'rytha'
#'@author Omar Benites
#'@details Formula for calculating total root yield
#'@keywords sweetpotato, agronomy,harvest,quantitative-continuous,yield,
#'@family sweetpotato,quality,harvest
#'@export 
#'
rytha <- function(crw=NULL,ncrw=NULL,pls=NA){
  
  if(is.na(pls)){
    rytha <- rep(NA, length(crw))
  } else{
    #if(!missing(crw) && missing(ncrw) )  {rytha <- (crw*10)/pls}  
    if(!is.null(crw) && is.null(ncrw))    {rytha <- (crw*10)/pls}  
    #if(missing(crw) && !missing(ncrw))   {rytha <- (ncrw*10)/pls}
    if(is.null(crw)  && !is.null(ncrw))   {rytha <- (ncrw*10)/pls}
    if(!is.null(crw) && !is.null(ncrw))   {rytha <- apply(cbind(crw,ncrw),1,sbsum)*10/pls}  
  }
  
  return(rytha)
}
