# CIP RIU Packages --------------------------------------------------------

#' @title Get the list of CIP-RIU packages
#' @author Omar Benites
#' @param repodir repository directory
#' @description Get log list of cipriu packages uploaded to github
#' @importFrom dplyr %>%
#' @export
#' 
get_cipriu_listpkg <- function(repodir= "D:/HIDAP_PACAKGES/GITHUB/") {

    ## TODO need to deal with binary repos...
    repodir <- repodir
    
    ##ext <- "_.*\\.tar\\..*$"            # with a nod to src/library/tools/packages.R
    ext <- "\\.tar\\..*$"            
    files <- list.files(repodir, pattern=ext, full.names=FALSE)
    
    ## subst. out the extension
    noextfiles <- gsub(ext, "", files)
    
    ## package names to the left
    pkgs <- sapply(strsplit(files, "_", fixed=TRUE), "[", 1L)
    
    ## versions is then the remainder to the right -- FIXME for something better
    verstxt <- gsub("[a-zA-Z0-9\\.]*_", "", noextfiles)
    
    ## parse into proper version objects -- thanks, base R!
    vers <- package_version(verstxt) %>% as.character() 
    
    url <- paste("https://cip-riu.github.io/cipriu_cran/packages/", files, sep="")
    
    cipriu_pkg <- data.frame(file=files, Package=pkgs, Version=vers, url=url,  stringsAsFactors = FALSE) %>% tibble::as_data_frame()

}

# USER OR LOCAL PACKAGES --------------------------------------------------

#' @title Get User Packages
#' @author Omar Benites
#' @description  Get the list of user packages from computers
#' @export
#' 
get_user_pkgs <- function(){ 

  user_pkg <- installed.packages()
  user_pkg <- tibble::as_data_frame(user_pkg)

}

# pkg_list <- list(
#   user = user_pkg,
#   cipriu = cipriu_pkg
# )


#' @title Get Log File from CIPRIU PACKAGES
#' @author Omar Benites
#' @param repodir repository directory
#' @description Get log list of cipriu packages uploaded to github

logtable_cipriu_pkg <- function(repodir="D:/HIDAP_PACAKGES/GITHUB/", dest_folder= "D:/HIDAP_PACAKGES/Production_HIDAP_Files/cipriu_cran/packages/" , file= "table_cipriu_pkg.csv"){
  
  table_pks <- get_cipriu_listpkg(repodir)
  file_name <- file.path(dest_folder, file)
  
  #saveRDS(object = table_pks,file = "D:/HIDAP_PACAKGES/Production_HIDAP_Files/cipriu_cran/packages/table_cipriu_pkg.rds")
  write.csv(x = table_pks, file = file_name, row.names = FALSE, na = "")
  
}

#' @title Get URL Log File from CIPRIU PACKAGES
#' @author Omar Benites
#' @description Get URL Log File with the list of cipriu packages uploaded to github

get_url_cipRiuLog <- function(){

  #todo: check if it works with rds, but use readcsv
  out <- list(
              link_rds = "https://cip-riu.github.io/cipriu_cran/packages/table_cipriu_pkg.rds",
              link_csv = "https://cip-riu.github.io/cipriu_cran/packages/table_cipriu_pkg.csv"
          )
}


#' @title Table which has been obtained using RIU CRAN csv file
#' @author Omar Benites
#' @description Get table through cip riu cran repository
#' @export

get_cipriutable_github <- function(){
  
  riucran_table <-  read.csv("https://cip-riu.github.io/cipriu_cran/packages/table_cipriu_pkg.csv", stringsAsFactors = FALSE) 
  #dt <- read.csv(riucran_table)
  
}

#' @title Check Internet Connection
#' @author Omar Benites
#' @description pin to the url. 
#' @param url url to check connection.
#' @export


# check_internet_connection <- function (url = "www.google.org") 
# {
#   #curl::has_internet()
#   !is.null(curl::nslookup(url, error = FALSE))
# }
