context("infrastructure")
# 
# td <- tempdir()
# unlink(file.path(td, "R"))

test_that("check ttwp formula", {
  expect_that(ttwp("a","b","c"), throws_error())  
  expect_that(ttwp(mtwci = NA,mtwcii = NA,nomtwp = NA),is_equivalent_to(NA))

})

test_that("check cip_number_check",{
  a <- sbformula::cip_number_check("CIP123456.123")
  b <- sbformula::cip_number_check("CIP123456")
  
  expect_that((a$cipnumber_ok),is_equivalent_to("CIP123456.123"))
  expect_that((b$cipnumber_ok),is_equivalent_to("CIP123456"))
  expect_that(str(a),prints_text("List of 2"))
  expect_that(sbformula::cip_number(),throws_error())
})

test_that("Check PWL_SPT and PWL_RSPT",{
  FTWRSPT <- rep(NA, 10)
  ITW <- 1:10
  answer <- rep(NA, 10)
  fml_anwer <- sbformula::pct_if(inital_value = ITW, final_value = -FTWRSPT)
  testthat::expect_that(fml_anwer, is_equivalent_to(NA))

})

test_that("Check RYTHA with NA",{

  crw  <- rnorm(1000,10,1.2)
  crw[c(1,2,3,78)] <- NA
  ncrw <- rnorm(1000,11,1.2)
  ncrw[c(1,2,61,4)] <- NA
  pls <- 0.9
  res <- sbformula::rytha(crw = crw,ncrw = ncrw ,pls = pls)
  desire <- as.double(c(NA,NA))
  expect_equal(res[1:2],desire)
  
})
#   
test_that("Calculate DMRY using RYTHA and dm",{
  set.seed(1234)
  crw  <- rnorm(1000,10,1.2)
  crw[c(1,2,3,78)] <- NA
  rytha <- rnorm(1000,16,3)
  rytha[c(1,3,5,78)] <- NA
  dm <-  rnorm(1000,30,3)
  dm[c(1,2,16,78)] <- NA
  res <- sbformula::dmry(rytha = rytha,dm = dm )
  desire <- rytha*dm/100 #formula without function
  expect_equal(res, desire)
})

test_that("calculation of DMRY when dm is equal NULL",{
  set.seed(1234)
  rytha <- rnorm(1000,16,3)
  dm <-  NULL
  res <- sbformula::dmry(rytha = rytha,dm = dm )
  desire <- NA  #formula without function
  expect_equal(res, desire)
})

test_that("calculation of DMRY using CRW and NCRW",{
  set.seed(1234)
  crw  <- rnorm(1000,10,1.2)
  crw[c(1,2,3,78)] <- NA
  ncrw <- rnorm(1000,11,1.2)
  ncrw[c(1,2,61,4)] <- NA
  dm <-  rnorm(1000,30,3)
  res <- sbformula::dmry(crw = crw,ncrw = ncrw,dm = dm)
  desire <- dmry <- apply(cbind(crw, ncrw), 1, sbsum)*dm/100 #formula without function
  expect_equal(res, desire)
})

test_that("Check AVDM",{
 
   set.seed(1234)
   dm1 <- rnorm(n = 6,mean = 20,sd = 5)
   dm1[c(1,5)] <- NA
   
   dm2 <- rnorm(n = 6,mean = 20,sd = 5)
   dm2[c(2,4)] <- NA
   
   avdm <- round(c( 17.126300, 21.387146, 21.299973 , 8.271511, 17.614037, 18.769174),digits = 2)
   
   avdm_direct <- sbformula::avdm(dm1 = dm1, dm2 = dm2)
   avdm_direct <- round(avdm_direct,2)
   
   expect_equal(avdm, avdm_direct)
  
})

test_that("Check AVDM with NA",{
  
  #set.seed(1234)
  dm1 <- rep(NA,5)
  dm2 <- rep(NA,5)
  avdm <- c(NaN, NaN, NaN, NaN, NaN)
  avdm_direct <- sbformula::avdm(dm1 = dm1, dm2 = dm2)
  expect_equal(avdm, avdm_direct)
  
})

test_that("Check AVDM with NULL",{
  
  #set.seed(1234)
  dm1 <- NULL
  dm2 <- NULL
  avdm <- NULL
  avdm_direct <- sbformula::avdm(dm1 = dm1, dm2 = dm2)
  expect_equal(avdm, avdm_direct)
  #testthat::expect_that(avdm_result, is_equivalent_to(NA))
  
})

test_that("Check NA values for biochemichal content",{
  
  bch <- rep(NA, 100)
  dm <- 1:100
  biochem_cont(biochem = bch, dm = dm)
  expect_that(length(biochem_cont(biochem = bch, dm = dm)), equals(100))
  
  
})

# 
test_that("Drought Indexes", {

   
   
   

})
# 




# test_that("",{
#   
#   
#   PLAHE_SLP <- ((DAP_EV1-DAP_AV)*(PLAHE_EV1-PLAHE_AV)+(DAP_EV2-DAP_AV)*(PLAHE_EV2-PLAHE_AV)+(DAP_EV3-DAP_AV)*(PLAHE_EV3-PLAHE_AV)+(DAP_EV4-DAP_AV)*(PLAHE_EV4-PLAHE_AV))/((DAP_EV1-DAP_AV)^2 + (DAP_EV2-DAP_AV)^2+(DAP_EV3-DAP_AV)^2+(DAP_EV4-DAP_AV)^2)
#   
#   
# })



# 
# test_that("Average of plant height Evaluation",{
#   
#   set.seed(1234)
#   dm1 <- rnorm(n = 6,mean = 20,sd = 5)
#   dm1[c(1,5)] <- NA
#   dm2 <- rnorm(n = 6,mean = 20,sd = 5)
#   dm2[c(2,4)] <- NA
#   
#   avdm_direct <- sbformula::avdm(dm1 = dm1, dm2 = dm2)
#   avdm_direct <- round(avdm_direct,2)
#   
#   expect_equal(avdm, avdm_direct)
#   
# })

