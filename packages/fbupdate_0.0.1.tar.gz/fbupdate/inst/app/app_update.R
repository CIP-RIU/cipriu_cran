library(shinydashboard)
library(shiny)
library(data.table)
library(rhandsontable)
library(traittools)
library(sbformula)
library(openxlsx)
library(shinyFiles)
library(date)
library(agricolae)
library(doBy)
library(readxl)
library(shinyTree)
library(fbdesign)
library(shinyjs)
library(remotes)


tabNameS <- "update"

server <- function(input, output, session,values) {
  values = shiny::reactiveValues()
  fbupdate::fbupdate_server(input, output, session, values = values)
}

ui <- dashboardPage(skin = "yellow",
                    dashboardHeader(title = "HIDAP UPDATE"),
                    dashboardSidebar(width = 350,
                                     menuItem("Resources",
                                              sidebarMenu(id = "menu",
                                                          menuSubItem("Data Processing", icon = icon("location-arrow"),
                                                                      tabName = tabNameS)
                                              )
                                     )
                    ),
                    dashboardBody(
                      tabItems(
                        fbupdate::fbupdate_ui(name = tabNameS)
                      )
                    )
)

shinyApp(ui = ui, server = server)


