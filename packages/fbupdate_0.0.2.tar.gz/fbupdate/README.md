---
title: "README"
author: "Omar Benites"
date: "August 25, 2017"
output: html_document
---

```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = TRUE)
```

## Requisites

- Verify if exist Internet Connection *(Done)*
- At least R v.3.1.0 is requiered *(Done)*
- Check what are the user packages *(Done)*
- Check what are the CIP RIU packages *(Done)*
- Cross-checking between User packages and CIP-RIU packages 

- Create 2 buttons: Check packages and Update Packages. Both buttons verify
  - If v.user != v.cip_riu_cran then install  *(Done)*
  - if v.cip_riu package is not installed, then install.
  - if v.user == v.cip_riu_cran then do not install *(Done)*
  
  For these these 3 items we can use   `left_join(user,riu, by= c("Package", "Version"))`
  
- Finally create a 3rd button: Refresh HIDAP. *(Done)*

## Internal Infraestructure

- Clean all this folder "D:/HIDAP_PACAKGES/Production_HIDAP_Files/cipriu_cran/packages"
- Locate all the new (zip/.tar/gz) files in "D:/HIDAP_PACAKGES/Production_HIDAP_Files/cipriu_cran/packages"
- use git2r to commit and push packages to Github (https://cip-riu.github.io/cipriu_cran/)
- Use fbupdate::logtable_cipriu_pkg to create csv file with the log list of new r-package versions


