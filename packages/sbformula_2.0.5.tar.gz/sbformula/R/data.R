
#' @name augbd augmendted block design data using factors and subsamples
#' @title trial data of an augmented block design experiment using factor with three levels. Beside it has subsample per genotype
#' @docType data
#' @aliases augbd
#' @description This dataset contains data which comes from experiment using factors and sub sampling.
#' @references This data is related to HiDAP fbcheck module.
#' @usage augbd
#' @format data frame
#' @source International Potato Center, potato and sweet potato experimental data.
NULL
