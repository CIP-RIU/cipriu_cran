#' Server component for traittools in fbcheck
#'
#' Returns server side components
#' @author Omar Benites
#' @param input shinyserver input
#' @param output nameo of the output element
#' @param session shinyserver session
#' @param values The reactive values
#' @importFrom remotes install_url
#' @export

fbupdate_server <- function(input, output, session, values) {
  
  #Catch the file path for reading fieldbook sheets
  # volumes <- shinyFiles::getVolumes()
  # shinyFileChoose(input, 'file', roots=volumes, session=session,
  #                 restrictions=system.file(package='base'),filetypes=c('xlsx'))
  
  #Reactive table for cross-checking packages
  dtpkg <- reactive({
    
    #left_join(user,riu, by= c("Package", "Version"))
    
    riu <- get_cipriutable_github()
    user <- get_user_pkgs() 
    
    #filter identical packages which are in the cloud 
    #res <- filter(.data = user, Package %in% riu$Package)
    res <- filter(.data = user, Package %in% riu$Package)
    #filter which version is out-of-date
    update_pkgs <- filter(riu, Version > res$Version)
    
    up2 <- filter(riu, res$Package!=riu$Package)
    
    update_pkgs
    
  })


# Check package in the github server (for updating) -----------------------

  output$hot_table_checkpkg  <-  renderRHandsontable({
    
    req(input$fbupdate_btnCheck)
    
    
   
    
    # riu <- get_cipriutable_github()
    # user <- get_user_pkgs() 
    # 
    # #filter identical packages which are in the cloud 
    # res <- filter(.data = user, Package == riu$Package)
    # #filter which version is out-of-date
    # update_pkgs <- filter(riu, Version > res$Version)
    
    withProgress(message = 'Checking for updates', value = 0, {
    
      incProgress(1/3, detail = paste("Checking for updates"))  
      
      update_pkgs <- dtpkg()
      
      incProgress(2/3, detail = paste("Loading updates")) 
      
      if(nrow(update_pkgs)==0){  update_pkgs <- data.frame(Packages ="There are no packages for updating")}
      rhandsontable::rhandsontable(data = update_pkgs, height = 780)
      
    
    })
   
  })

  
  # Update packages ---------------------------------------------------------
  
  shiny::observeEvent( input$fbupdate_btnUpdate, {
    
    url <- dtpkg()$url 
    r_version <- getRversion() %>% as.character()
    
    withProgress(message = 'Update', value = 0, {
      
      if(length(url)==0){ #check if exist 
        #flag <- FALSE
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("ERROR: There are no package for updating"), styleclass = "warning")
      } else if(!curl::has_internet()){ #check internet connection
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("ERROR: There is no internet connection. Check your connection"), styleclass = "danger")
      
      } else if(r_version>="3.3.0"){
        shinysky::showshinyalert(session, "alert_fbupdate_done", paste("ERROR: Your have an older version of R" , r_version ," At least you requiere the R 3.3.1 version"), styleclass = "danger")
        
      } else {
        remotes::install_url(url, dependencies= FALSE)
        
      }  
      #remotes::install_url("https://cip-riu.github.io/cipriu_cran/packages/traittools_1.0.1.tar.gz", dependencies = FALSE)
      
    })  
    
  }) 
  
  #Refresh Page button
  observeEvent(input$fbupdate_btnRefresh, {
    
    withProgress(message = 'Refresh', value = 0, {
      
      incProgress(2/3, detail = paste("Refreshing Hidap..."))  
    
      incProgress(3/3, detail = paste("Refreshing Hidap..."))  
      
    shinyjs::js$refresh()
  })
    
  })
  
}



