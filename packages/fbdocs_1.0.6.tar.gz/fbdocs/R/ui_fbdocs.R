#' UI for HIDAP documentation
#' Returns user friendly ui
#' @author Omar Benites
#' @param type type of UI element, deault is a tab in a shinydashboard
#' @param title diaply title name
#' @param name UI TabName
#' @export
#'

fbdocs_ui <- function(type = "tab", title = "HIDAP Documents", name= "docshidap_fieldbooks"){

  #body <- dashboardBody(


          shinydashboard::tabItem(tabName = name, h2(title),

            fluidRow(
              column(width = 6,
                     box(
                       title = "HIDAP Installation Manual", width = NULL, solidHeader = TRUE, status = "warning",
                       "", collapsible = TRUE,

                       fluidRow(
                           column(6,
                                  shiny::HTML("<b>English</b>"),

                                  shiny::br(),
                                  shiny::actionButton("dochidap_install_launch_en", "Open",
                                                          icon = shiny::icon("folder-open", lib = "glyphicon"),
                                                          width = "100px",
                                                          style="color: #fff; background-color: #337ab7; border-color: #2e6da4"
                                                          ),
                                  shiny::br(),
                                  shiny::br(),
                                  shiny::HTML("<b>Spanish</b>"),
                                  shiny::br(),
                                  shiny::actionButton("dochidap_install_launch_es", "Open",
                                                      icon = shiny::icon("folder-open", lib = "glyphicon"),
                                                      width = "100px",
                                                      style="color: #fff; background-color: #337ab7; border-color: #2e6da4")#,

                            )#,


                       )
                     ),

                     ######
                     box( #begin box
                       title = "HIDAP user's manual", width = NULL, solidHeader = TRUE, status = "warning",
                       "", collapsible = TRUE,

                       fluidRow(
                         column(6,

                                shiny::HTML("<b>English</b>"),

                                shiny::br(),
                                shiny::actionButton("dochidap_navig_launch_en", "Open",
                                                    icon = shiny::icon("folder-open", lib = "glyphicon"),
                                                    width = "100px",
                                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4"),
                                shiny::br(),
                                shiny::br(),
                                shiny::HTML("<b>Spanish</b>"),
                                shiny::br(),
                                shiny::actionButton("dochidap_navig_launch_es", "Open",
                                                    icon = shiny::icon("folder-open", lib = "glyphicon"),
                                                    width = "100px",
                                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4")#,

                         )#,
                       )
                     ), #end box
                     ######


######
                     # shinydashboard::box( #begin box
                     #   title = "PVS Documentation", width = NULL, solidHeader = TRUE, status = "primary",
                     #   "Participatory Varietal Selection Documentation (PVS)", collapsible = TRUE,
                     #
                     #   shiny::fluidRow(
                     #     shiny::column(6,  shiny::actionButton("docpvsdic_launch", "Open",
                     #                                    icon = shiny::icon("folder-open", lib = "glyphicon"),
                     #                                    width = "100px",
                     #                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4"
                     #        )
                     #      )
                     #   )
                     #  ), #end box

######

######
                     box( #begin box
                       title = "Participatory Varietal Selection Documentation", width = NULL, solidHeader = TRUE, status = "primary",
                       "", collapsible = TRUE,

                       fluidRow( # pvs manual
                         column(6,

                                shiny::HTML("<b>Participatory Varietal Selection: Dictionary</b>"),
                                shiny::br(),

                                shiny::actionButton("docpvsdic_launch", "Open",
                                                    icon = shiny::icon("folder-open", lib = "glyphicon"),
                                                    width = "100px",
                                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4"
                                ),

                                shiny::br(),
                                shiny::br(),
                                shiny::HTML("<b>Participatory Varietal Selection: Selection Criteria</b>"),
                                shiny::br(),
                                shiny::actionButton("docpvscriteria_launch", "Open",
                                                    icon = icon("folder-open", lib = "glyphicon"),
                                                    width = "100px",
                                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4" )#,
                         )
                       )  #end # pvs manual

                    ), #end box
######

                  shiny::HTML("<p style='font-size:20px'>For further details about protocols and documentation, see the links below:
                              <ol>
                                <li style='font-size:20px'><a href='https://research.cip.cgiar.org/potatoknowledge/protocols.php' target='_new'>Potato protocols</a> </li>
                                <li style='font-size:20px'><a href='http://www.sweetpotatoknowledge.org/sections/research-procedures-protocols/' target='_new'>Sweet Potato protocols </a>  </li>
                              </ol>
                              </p>")
              )
            )
)

}



#
# # Preview the UI in the console
# shinyApp(ui = ui, server = function(input, output) { })
