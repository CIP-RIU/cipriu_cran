#' server_design
#'
#' Design field book
#'
#' @param input shinyserver input
#' @param output shinyserver output
#' @param session shinyserver session
## @param dom target dom element name
#' @param values reactive values
#' @author Omar Benites
#' @export
#'

server_design <- function (input, output, session, values)
  {
    material_table <- shiny::reactive({
      if (input$select_import == "Template") {
        mtl_temp <- input$file_mtlist
        if (is.null(mtl_temp)) {
          return()
        }
        if (!is.null(mtl_temp)) {
          if (input$fbdesign_gentemp == TRUE) {
            file.copy(mtl_temp$datapath, paste(mtl_temp$datapath,
                                               ".xlsx", sep = ""))
            mtl_parental <- readxl::read_excel(paste(mtl_temp$datapath,
                                                     ".xlsx", sep = ""), sheet = "Material_List_Parental")
            mtl_temp <- mtl_parental
          }
          else {
            file.copy(mtl_temp$datapath, paste(mtl_temp$datapath,
                                               ".xlsx", sep = ""))
            mtl_temp <- readxl::read_excel(paste(mtl_temp$datapath,
                                                 ".xlsx", sep = ""), sheet = "Material_List")
          }
          mtl_list <- as.list(mtl_temp)
        }
      }
      if (input$select_import == "Local List") {
        sel_list <- input$designFieldbook_sel_mlist
        if (is.null(sel_list) || sel_list == "") {
          return()
        }
        if (length(sel_list) > 0) {
          mtl_temp <- readRDS(sel_list)
          if (is_parentList(sel_list) == TRUE) {
            mtl_list <- mtl_temp
          }
          else {
            mtl_list <- as.list(mtl_temp)
          }
        }
      }
      mtl_list
    })
    output$approvalBox <- renderInfoBox({
      if (get_type_list_ds(material_table()) == "clonal") {
        germoplasm <- material_table()$Accession_Number
        germ_duplicates <- anyDuplicated(germoplasm)
        if (is.null(germoplasm)) {
          title <- "Upload"
          subtitle <- paste("your material list file. Or, press the button below to download and fill the template.")
          color <- "blue"
          icon <- "upload"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else if (all(is.na(germoplasm))) {
          title <- "ERROR"
          subtitle <- paste("Your material list", "is empty. Please check it")
          color <- "red"
          icon <- "warning-sign"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else if (germ_duplicates > 0) {
          title <- "ERROR"
          subtitle <- paste("Your material list has duplicated genotypes/germplasm names. Please, enter a correct file.")
          color <- "red"
          icon <- "warning-sign"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else {
          title <- "GREAT!"
          subtitle <- paste(" was successfully uploaded!")
          color <- "green"
          icon <- "ok"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
      }
      if (get_type_list_ds(material_table()) == "parental") {
        if (input$fbdesign_gentemp == TRUE) {
          germoplasm_fem <- material_table()$Accession_Number_Female
          germoplasm_male <- material_table()$Accession_Number_Male
        }
        else {
          germoplasm_fem <- material_table()$female$Accession_Number
          germoplasm_male <- material_table()$male$Accession_Number
        }
        if (is.null(germoplasm_fem) && is.null(germoplasm_male)) {
          title <- "Upload"
          subtitle <- paste(" your parental list file. Or, press the button below to download and fill the template.")
          color <- "blue"
          icon <- "upload"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else if (all(is.na(germoplasm_fem))) {
          title <- "ERROR"
          subtitle <- paste("The female's accession numbers are empty.",
                            "Please check female's accesion number column")
          color <- "red"
          icon <- "warning-sign"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else if (all(is.na(germoplasm_male))) {
          title <- "ERROR"
          subtitle <- paste("The male's accession numbers are empty")
          color <- "red"
          icon <- "warning-sign"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
        else {
          title <- "GREAT!"
          subtitle <- paste(" your parental list file was successfully uploaded!")
          color <- "green"
          icon <- "ok"
          lib <- "glyphicon"
          fill <- TRUE
          width <- NULL
        }
      }
      shinydashboard::infoBox(title = title, subtitle = subtitle,
                              icon = icon(icon, lib = lib), color = color, fill = TRUE,
                              width = NULL)
    })
    output$fbDesign_variables <- shiny::renderUI({
      crop <- input$designFieldbook_crop
      if (crop == "potato") {
        tbl <- table_module_potato
      }
      if (crop == "sweetpotato") {
        tbl <- table_module_sweetpotato
      }
      mdl <- tbl[tbl$CROP == crop, c("TRIAL_ABBR", "TRIAL")]
      mdl <- paste0(mdl[, 2], " (", mdl[, 1], ")")
      mdl <- sort(unique(mdl))
      ids <- str_trim(gsub("\\(.*", "", mdl), side = "both")
      vls <- mdl
      mdl <- as.list(ids)
      names(mdl) <- vls
      shiny::selectInput("designFieldbook_module", label = "Type of trial",
                         choices = mdl, selected = 1)
    })
    fbdesign_id <- shiny::reactive({
      if (!is.null(input$designFieldbook_crop)) {
        tbl <- table_crops
        nExp_id <- input$fbDesign_nExp
        crop_id <- tbl[tbl$crop_name == input$designFieldbook_crop,
                       "crop_id"]
        program_id <- input$designFieldbook_program
        phase_id <- input$designFieldbook_phase
        module_id <- input$designFieldbook_module
        date_book <- input$fbDesign_project_time_line[1]
        date_book <- unlist(str_split(date_book, "-"))
        date_book <- paste(date_book[2], date_book[1], sep = "")
        sites <- stringr::str_trim(input$designFieldbook_sites,
                                   side = "both")
        if (nExp_id == "-") {
          out <- paste0(crop_id, program_id, phase_id,
                        module_id, date_book, "_", sites)
        }
        else {
          out <- paste0(crop_id, program_id, phase_id,
                        module_id, date_book, "_", sites, "_", nExp_id)
        }
        paste(out, collapse = ", ")
      }
    })
    output$fbDesign_id <- shiny::renderText({
      fbdesign_id()
    })
    output$designFieldbook_traits <- shinyTree::renderTree({
      a <- Trait_List
    })
    output$fbdesign_split_cb <- shiny::renderUI({
      choices <- c(input$factor_name, "INSTN")
      shiny::selectInput("designFieldbook_split_cb", label = "Factor to Plots",
                         choices = choices, selected = "INSTN")
    })
    shiny::observe({
      path <- fbglobal::get_base_dir()
      geodb_file <- "table_sites.rds"
      path <- file.path(path, geodb_file)
      values$sites_data <- readRDS(file = path)
    })
    output$fbDesign_country <- shiny::renderUI({
      sites_data <- values$sites_data
      cntry <- fbsites::get_country_list(sites_data = sites_data)
      shiny::selectizeInput("fbDesign_countryTrial", label = "Country",
                            choices = cntry, selected = 1, multiple = FALSE)
    })
    fbdesign_sites <- reactive({
      sites_data <- values$sites_data
      fbsites::get_filter_locality(sites_data = sites_data,
                                   country_input = input$fbDesign_countryTrial)
    })
    output$fbDesign_countrySite <- shiny::renderUI({
      req(input$fbDesign_countryTrial)
      locs <- values$sites_data
      fbdesign_sites_selected <- fbdesign_sites()
      if (nrow(locs) > 0) {
        shiny::selectizeInput("designFieldbook_sites", label = "Location",
                              choices = fbdesign_sites_selected, selected = 1,
                              multiple = FALSE)
      }
    })
    output$oufbDesign_country_fbapp <- shiny::renderUI({
      sites_data <- values$sites_data
      cntry <- fbsites::get_country_list(sites_data = sites_data)
      div(style = "display: inline-block;vertical-align:top; width: 200px;",
          shiny::selectInput("fbdesign_cntry_fbapp", label = "Select Country",
                             choices = cntry, selected = 1, multiple = FALSE))
    })
    fbdesign_sites_app <- reactive({
      sites_data <- values$sites_data
      fbsites::get_filter_locality(sites_data = sites_data,
                                   country_input = input$fbdesign_cntry_fbapp)
    })
    output$oufbDesign_location_fbapp <- shiny::renderUI({
      req(input$fbdesign_cntry_fbapp)
      locs <- values$sites_data
      fbdesign_sites_selected <- fbdesign_sites_app()
      if (nrow(locs) > 0) {
        div(style = "display: inline-block;vertical-align:top; width: 200px;",
            shiny::selectizeInput("fbdesign_location_fbapp",
                                  label = "Select Location", choices = fbdesign_sites_selected,
                                  selected = 1, multiple = FALSE))
      }
    })
    output$fbDesign_selmlist <- shiny::renderUI({
      input$fdesign_list_refresh
      res <- fbdesign_mtl_files()
      selectizeInput(inputId = "designFieldbook_sel_mlist",
                     label = "Select a material list", width = "100%",
                     choices = res, options = list(placeholder = "Select a material list",
                                                   onInitialize = I("function() { this.setValue(\"\"); }")))
    })
    output$condition_selmlist <- shiny::reactive({
      mlist <- material_table()
      if (is.null(mlist) || mlist == "") {
        out <- 0
      }
      tp <- get_type_list_ds(mlist)
      if (tp == "parental") {
        out <- 1
      }
      if (tp == "clonal") {
        out <- 0
      }
      return(out)
    })
    outputOptions(output, "condition_selmlist", suspendWhenHidden = FALSE)
    react_plantxplot <- shiny::reactive({
      plantxplot <- input$fbDesign_nplantsrow * input$fbDesign_nrowplot
      if (length(plantxplot) == 0) {
        plantxplot <- 0
      }
      plantxplot
    })
    output$fbPlant_plot <- shiny::renderUI({
      rpplot <- react_plantxplot()
      shiny::numericInput("fbDesign_nplants", "Number of plants per plot",
                          rpplot, rpplot, rpplot)
    })
    react_psize <- reactive({
      plot_size <- input$fbDesign_nplantsrow * input$fbDesign_distPlants *
        input$fbDesign_nrowplot * input$fbDesign_distRows
      print(plot_size)
      if (length(plot_size) == 0) {
        plot_size <- 0
      }
      plot_size
    })
    output$fbPlanting_psize <- shiny::renderUI({
      plot_size <- react_psize()
      shiny::numericInput(inputId = "fbDesign_psize", label = "Plot size (m2)",
                          value = plot_size, min = plot_size, max = plot_size)
    })
    react_pdensity <- shiny::reactive({
      nplantxplot <- react_plantxplot()
      plant_density <- (nplantxplot/input$fbDesign_psize) *
        10000
      print(plant_density)
      if (length(plant_density) == 0) {
        plant_density <- 0
      }
      plant_density
    })
    output$fbPlanting_pdensity <- shiny::renderUI({
      plant_density <- react_pdensity()
      shiny::numericInput(inputId = "fbDesign_pdensity", label = "Plant density (plants/Ha)",
                          value = plant_density, min = plant_density, max = plant_density)
    })
    output$alphaMessage <- shiny::renderText({
      germoplasm <- material_table()$Accession_Number
      if (!is.null(germoplasm)) {
        print(germoplasm)
        n <- length(germoplasm)
        r <- as.numeric(input$designFieldbook_r)
        k <- as.numeric(input$designFieldbook_k)
        dach <- design.alpha.check(trt = germoplasm, k = k,
                                   r = r)
        if (!dach$alfares) {
          paste(dach$res, ". The combination of ", r, " and",
                k, " is wrong using ", n, " genotypes.")
        }
        else {
          paste("The combination of replication (r) and block size (k) is perfect!")
        }
      }
      else {
        paste("Enter your genotypes in the Germoplams List.")
      }
    })
    fbdraft <- shiny::reactive({
      if (input$select_import == "Template") {
        req(input$file_mtlist)
      }
      if (input$select_import == "Local List") {
        req(input$designFieldbook_sel_mlist)
      }
      try({
        withProgress(message = "Fieldbook loading...", detail = "This may take a while...",
                     value = 0, {
                       incProgress(3/15)
                       crp <- input$designFieldbook_crop
                       material_tbl = material_table()
                       incProgress(4/15)
                       is_parental <- is_parentList(input$designFieldbook_sel_mlist)
                       tpds <- get_type_list_ds(material_tbl)
                       if (tpds == "parental") {
                         trt1 <- NULL
                         trt2 <- NULL
                         design <- input$design_geneticFieldbook
                         if (design == "NCI" || design == "NCII") {
                           if (input$fbdesign_gentemp == TRUE) {
                             male <- material_tbl$Accession_Number_Female
                             female <- material_tbl$Accession_Number_Male
                           }
                           else {
                             male <- material_tbl$male$Accession_Number
                             female <- material_tbl$female$Accession_Number
                           }
                           set <- input$design_genetic_nc_set
                           r <- input$design_genetic_r
                           if (design == "NCI") {
                             trt1_label = "MALE"
                             trt2_label = "FEMALE"
                           }
                           if (design == "NCII") {
                             trt1_label = "FEMALE"
                             trt2_label = "MALE"
                           }
                         }
                         if (design == "LXT") {
                           if (input$fbdesign_gentemp == TRUE) {
                             male <- material_tbl$Accession_Number_Female
                             female <- material_tbl$Accession_Number_Male
                           }
                           else {
                             male <- material_tbl$male$Accession_Number
                             female <- material_tbl$female$Accession_Number
                           }
                           trt1_label <- "LINE"
                           trt2_label <- "TESTER"
                           type_lxt_scheme <- input$design_genetic_lxt_type
                           r <- input$design_genetic_r
                         }
                       }
                       if (tpds == "clonal") {
                         trt1 <- material_tbl$Accession_Number
                         trt1 <- gsub("[[:space:]]", "", trt1)
                         trt1 <- setdiff(trt1, "")
                         trt1_label <- "INSTN"
                         trt2_label <- "FACTOR"
                         design <- input$designFieldbook
                         r <- input$designFieldbook_r
                         sub_design <- as.character(input$sub_design)
                         if (is.null(sub_design))
                           sub_design <- NULL
                         print(input$factor_lvl)
                         factor_lvl <- strsplit(x = input$factor_lvl,
                                                ",")[[1]]
                         factor_lvl <- factor_lvl %>% stringr::str_trim(.,
                                                                        side = "both")
                         factor_lvl <- gsub("\\s+", replacement = "_",
                                            factor_lvl)
                         trt2 <- factor_lvl
                         trt2 <- trt2[!is.na(trt2) & trt2 != ""]
                         if (input$designFieldbook == "SPCRD" || input$designFieldbook ==
                             "SPRCBD") {
                           if (input$designFieldbook_split_cb == "INSTN") {
                             trt1 <- trt1
                             trt2 <- trt2
                           }
                           else {
                             genotypes <- trt1
                             factor <- trt2
                             trt1 <- factor
                             trt2 <- genotypes
                             trt1_label <- "FACTOR"
                             trt2_label <- "INSTN"
                           }
                         }
                         if (input$designFieldbook == "ABD") {
                           trt1 <- is_control(material_tbl)
                           print(trt1)
                           trt2 <- material_tbl$Accession_Number
                           trt2 <- setdiff(trt2, trt1)
                           print(trt2)
                         }
                         if (input$designFieldbook == "WD") {
                           trt2 <- is_control(material_tbl)
                           trt1 <- setdiff(trt1, trt2)
                           male <- NULL
                           female <- NULL
                           set <- NULL
                         }
                       }
                       incProgress(6/15)
                       mdl <- input$designFieldbook_module
                       mdl <- stringr::str_extract(mdl, "([A-Z]{2})")[[1]]
                       vars <- get_tree_value(input$designFieldbook_traits,
                                              crop_selected = crp)
                       if (crp == "potato") {
                         tbl <- table_module_potato
                       }
                       if (crp == "sweetpotato") {
                         tbl <- table_module_sweetpotato
                       }
                       mdl <- tbl[tbl$CROP == crp, c("TRIAL_ABBR",
                                                     "TRIAL")]
                       mdl <- paste0(mdl[, 2], " (", mdl[, 1], ")")
                       mdl <- sort(unique(mdl))
                       ids <- str_trim(gsub("\\(.*", "", mdl), side = "both")
                       vars <- vars[!(vars %in% ids)]
                       incProgress(8/15)
                       fb = design_fieldbook(design = design, trt1 = trt1,
                                             trt2 = trt2, sub_design = input$sub_design,
                                             trt1_label = trt1_label, trt2_label = trt2_label,
                                             r = as.integer(r), type_lxt = as.integer(type_lxt_scheme),
                                             k = as.integer(input$designFieldbook_k),
                                             number_col = as.integer(input$designFieldbook_wd_col),
                                             number_colb = as.integer(input$designFieldbook_wd_colb),
                                             set = set, male = male, female = female,
                                             first = TRUE, cont = as.logical(input$designFieldbook_cont),
                                             series = as.integer(input$designFieldbook_serie),
                                             zigzag = FALSE, variables = vars)
                       is_combfactor <- input$designFieldbook_combfactor
                       combfactorName <- input$combfactor_name
                       comfactorLvl <- input$combfactor_lvl
                       print(comfactorLvl)
                       if (is_combfactor) {
                         comfactorLvl <- strsplit(x = comfactorLvl,
                                                  ",")[[1]]
                         comfactorLvl <- comfactorLvl %>% stringr::str_trim(.,
                                                                            side = "both")
                         comfactorLvl <- gsub("\\s+", replacement = "_",
                                              comfactorLvl)
                         comfactorLvl <- comfactorLvl[!is.na(comfactorLvl) &
                                                        comfactorLvl != ""]
                         fb_list <- vector(mode = "list", length = length(comfactorLvl))
                         for (i in 1:length(comfactorLvl)) {
                           fb_list[[i]] <- add_cl(fb = fb, design_abr = design,
                                                  factor_lvl = comfactorLvl[i])
                         }
                         fb <- data.table::rbindlist(fb_list, fill = TRUE) %>%
                           as.data.frame()
                       }
                       is_ssample <- input$designFieldbook_cbssample
                       print(is_ssample)
                       if (is_ssample) {
                         nsample <- input$designFieldbook_nsample
                         ncol_fb <- ncol(fb)
                         p1 <- as.list(rep(NA, times = nsample))
                         names(p1) <- 1:nsample
                         fb <- cbind(fb, p1)
                         print("paso1")
                         print(fb)
                         fb <- reshape2::melt(fb, 1:ncol_fb)
                         print("paso2")
                         fb <- fb %>% dplyr::select(-value)
                         inst_pos <- which(names(fb) == "INSTN")
                         print(inst_pos)
                         fb <- append_col(fb, list(SUBSAMPLE = fb$variable),
                                          after = inst_pos) %>% dplyr::select(-variable)
                       }
                       incProgress(12/15)
                       fb[, 1] <- as.integer(fb[, 1])
                       incProgress(15/15)
                       fb
                     })
      })
    })
    shiny::observeEvent(input$fbDesign_draft, {
      mtl_table <- material_table()
      tpds <- get_type_list_ds(material_table())
      flag <- TRUE
      if (length(material_table()) == 0) {
        flag <- FALSE
        shinysky::showshinyalert(session, "alert_fb_done",
                                 paste("ERROR: You have not selected a material list. Please select/upload one"),
                                 styleclass = "danger")
      }
      if (input$designFieldbook == "ABD") {
        mtl <- as.data.frame(mtl_table)
        mtl_instn <- as.character(mtl$Is_control)
        mtl_checks_count <- is_control(mtl_table)
        if (all(is.na(mtl_instn)) || length(mtl_checks_count) ==
            1) {
          flag <- FALSE
          shinysky::showshinyalert(session, "alert_fb_done",
                                   paste("ERROR: in Augmented Design: At least two checks is needed in 'Is_Control' column. Verify Material List file"),
                                   styleclass = "danger")
        }
        else {
          flag <- TRUE
        }
      }
      if (input$designFieldbook == "WD") {
        mtl <- as.data.frame(mtl_table, stringsAsFactors = FALSE)
        trt1 <- mtl_table$Accession_Number
        trt1 <- gsub("[[:space:]]", "", trt1)
        trt1 <- setdiff(trt1, "")
        mtl_instn <- as.character(mtl$Is_control)
        mtl_checks_count <- is_control(mtl_table)
        trt2 <- is_control(mtl_table)
        germoplasm <- setdiff(trt1, trt2)
        germoplasm <- trt1
        if (all(is.na(mtl_instn)) || length(mtl_checks_count) ==
            1 || length(mtl_checks_count) > 2) {
          flag <- FALSE
          shinysky::showshinyalert(session, "alert_fb_done",
                                   paste("ERROR: Just two checks are needed in Westcott Design. Verify 'Is_Control' column in your material list"),
                                   styleclass = "danger")
        }
        else if (length(germoplasm) < 10) {
          shinysky::showshinyalert(session, "alert_fb_done",
                                   paste("You need at least 10 genotypes to perform Westcott Design."),
                                   styleclass = "danger")
        }
        else {
          flag <- TRUE
        }
      }
      if (input$designFieldbook == "AD") {
        germoplasm <- material_table()$Accession_Number
        print(germoplasm)
        n <- length(germoplasm)
        r <- as.numeric(input$designFieldbook_r)
        k <- as.numeric(input$designFieldbook_k)
        dach <- design.alpha.check(trt = germoplasm, k = k,
                                   r = r)
        if (!dach$alfares) {
          flag <- FALSE
          ms <- paste(dach$res, ". The combination of ",
                      r, " and", k, " is wrong using ", n, " genotypes.")
          shinysky::showshinyalert(session, "alert_fb_done",
                                   paste("ERROR: ", ms), styleclass = "danger")
        }
        else {
          flag <- TRUE
        }
      }
      if (tpds == "parental") {
        if (input$design_geneticFieldbook == "NCI") {
          if (input$fbdesign_gentemp == TRUE) {
            male <- mtl_table$Accession_Number_Female
            female <- mtl_table$Accession_Number_Male
          }
          else {
            male <- mtl_table$male$Accession_Number
            female <- mtl_table$female$Accession_Number
          }
          set <- as.numeric(input$design_genetic_nc_set)
          r <- as.numeric(input$design_genetic_r)
          print("pass")
          if (r == 1 || is.na(r)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: You have entered just 1 replication or NA/NULL values."),
                                     styleclass = "danger")
          }
          else if (is.null(male) || is.na(male)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: At minimimun 1 males"), styleclass = "danger")
          }
          else if (length(female) == 1 || is.null(female) ||
                   is.na(female)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: At minimimun 1 females"), styleclass = "danger")
          }
          else if (length(male)%%length(female) == 1) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: The number of males is not divisible by the number of females"),
                                     styleclass = "danger")
          }
          else if (length(female)%%length(male) == 1) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: Number of females must be proportional to number of males."),
                                     styleclass = "danger")
          }
          else if (length(male)%%set == 1) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: data length is not a multiple of set variable. Please provide an accurate number of sets"),
                                     styleclass = "danger")
          }
          else if ((length(female)/length(male)) == 1) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("The number of females must be at least twice the number of males. The material list does not meet this requirement"),
                                     styleclass = "danger")
          }
          else {
            flag <- TRUE
          }
        }
        if (input$design_geneticFieldbook == "NCII") {
          if (input$fbdesign_gentemp == TRUE) {
            male <- mtl_table$Accession_Number_Female
            female <- mtl_table$Accession_Number_Male
          }
          else {
            male <- mtl_table$male$Accession_Number
            female <- mtl_table$female$Accession_Number
          }
          set <- as.numeric(input$design_genetic_nc_set)
          r <- as.numeric(input$design_genetic_r)
          if (r == 1 || is.na(r)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: You have entered just 1 replication or NA/NULL values."),
                                     styleclass = "danger")
          }
          else if (is.null(male) || is.na(male)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: At minimimun 1 males"), styleclass = "danger")
          }
          else if (length(female) == 1 || is.null(female) ||
                   is.na(female)) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: At minimimun 1 females"), styleclass = "danger")
          }
          else if (length(male)%%set == 1) {
            flag <- FALSE
            shinysky::showshinyalert(session, "alert_fb_done",
                                     paste("ERROR: data length is not a multiple of set variable. Please provide an accurate number of sets"),
                                     styleclass = "danger")
          }
          else {
            flag <- TRUE
          }
        }
        flag <- flag
      }
      if (flag) {
        print(fbdraft())
        fb <- fbdraft()
        output$fbDesign_table <- rhandsontable::renderRHandsontable({
          rhandsontable::rhandsontable(fb, readOnly = T)
        })
      }
    })
    shiny::observeEvent(input$fbDesign_create, {
      withProgress(message = "Downloading Fieldbook...", value = 0,
                   {
                     incProgress(1/15)
                     fb = fbdraft()
                     print("fb in exporting")
                     try({
                       fn = paste0(fbdesign_id(), ".rda")
                       path <- fbglobal::get_base_dir()
                       fp <- file.path(path, fn)
                       is_parental <- is_parentList(input$designFieldbook_sel_mlist)
                       tpds <- get_type_list_ds(material_table())
                       if (tpds == "parental") {
                         r <- input$design_genetic_r
                         if (input$fbdesign_gentemp == TRUE) {
                           mtl_table <- material_table()
                         }
                         else {
                           mtl_table <- material_table()$parental_table
                         }
                       }
                       if (tpds == "clonal") {
                         r <- input$designFieldbook_r
                         mtl_table <- as.data.frame(material_table())
                       }
                       mtl_table <- mtl_table
                       begin_date <- input$fbDesign_project_time_line[1]
                       begin_date <- unlist(str_split(begin_date,
                                                      "-"))
                       begin_date1 <- paste(begin_date[3], begin_date[2],
                                            begin_date[1], sep = "/")
                       end_date <- input$fbDesign_project_time_line[2]
                       end_date <- unlist(str_split(end_date, "-"))
                       end_date1 <- paste(end_date[3], end_date[2],
                                          end_date[1], sep = "/")
                       genetic_design <- NA
                       type_of_ploidy <- NA
                       set <- NA
                       flag <- TRUE
                       if (length(mtl_table) == 0) {
                         flag <- FALSE
                         shinysky::showshinyalert(session, "alert_fb_done",
                                                  paste("ERROR: You have not selected a material list. Please select/upload one"),
                                                  styleclass = "danger")
                       }
                       if (input$designFieldbook == "ABD") {
                         mtl <- mtl_table
                         mtl_instn <- as.character(mtl$Is_control)
                         mtl_checks_count <- is_control(mtl_table)
                         print(mtl_checks_count)
                         if (all(is.na(mtl_instn)) || length(mtl_checks_count) ==
                             1) {
                           shinysky::showshinyalert(session, "alert_fb_done",
                                                    paste("ERROR: in Augmented Design: At least two checks are needed in 'Is_Control' column. Verify Material List file"),
                                                    styleclass = "danger")
                           flag <- FALSE
                         }
                         else {
                           flag <- TRUE
                         }
                       }
                       if (input$designFieldbook == "WD") {
                         mtl <- mtl_table
                         mtl_instn <- as.character(mtl$Is_control)
                         mtl_checks_count <- is_control(mtl_table)
                         if (all(is.na(mtl_instn)) || length(mtl_checks_count) ==
                             1 || length(mtl_checks_count) > 2) {
                           shinysky::showshinyalert(session, "alert_fb_done",
                                                    paste("ERROR in Westcott Design: Just two checks are needed in 'Is_Control' column. Verify your Material List file"),
                                                    styleclass = "danger")
                           flag <- FALSE
                         }
                         else {
                           flag <- TRUE
                         }
                       }
                       if (input$designFieldbook == "AD") {
                         germoplasm <- material_table()$Accession_Number
                         print(germoplasm)
                         n <- length(germoplasm)
                         r <- as.numeric(input$designFieldbook_r)
                         k <- as.numeric(input$designFieldbook_k)
                         dach <- fbdesign::design.alpha.check(trt = germoplasm,
                                                              k = k, r = r)
                         if (!dach$alfares) {
                           ms <- paste(dach$res, ". The combination of ",
                                       r, " and", k, " is wrong using ", n,
                                       " genotypes.")
                           shinysky::showshinyalert(session, "alert_fb_done",
                                                    paste("ERROR: ", ms), styleclass = "danger")
                           flag <- FALSE
                         }
                         else {
                           flag <- TRUE
                         }
                       }
                       if (input$designFieldbook_combfactor) {
                         factor_input <- input$combfactor_name
                         flevel_input <- input$combfactor_lvl
                       }
                       else {
                         factor_input <- input$factor_name
                         flevel_input <- input$factor_lvl
                       }
                       if (tpds == "parental") {
                         genetic_design <- input$design_geneticFieldbook
                         type_of_ploidy <- input$design_genetic_ploidy
                         set <- input$design_genetic_nc_set
                         if (input$design_geneticFieldbook == "NCI") {
                           if (input$fbdesign_gentemp == TRUE) {
                             male <- mtl_table$Accession_Number_Female
                             female <- mtl_table$Accession_Number_Male
                           }
                           else {
                             male <- mtl_table$Male_AcceNumb
                             female <- mtl_table$Female_AcceNumb
                           }
                           set <- as.numeric(input$design_genetic_nc_set)
                           r <- as.numeric(input$design_genetic_r)
                           print(male)
                           print(female)
                           if (length(male) != length(female)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: The length of males and females must be the same dimension"),
                                                      styleclass = "danger")
                           }
                           else if (r == 1 || is.na(r)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: You have entered just 1 replication or NA/NULL values."),
                                                      styleclass = "danger")
                           }
                           else if (is.null(male) || is.na(male)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: At minimimun 1 male"),
                                                      styleclass = "danger")
                           }
                           else if (length(female) == 1 || is.null(female) ||
                                    is.na(female)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: At minimimun 1 female"),
                                                      styleclass = "danger")
                           }
                           else if (length(female)%%set != 0) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: data length is not a multiple of set variable. Please provide an accurate number of sets"),
                                                      styleclass = "danger")
                           }
                           if (length(male)%%set == 1) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: It is not possible divide the number of males per number of sets."),
                                                      styleclass = "danger")
                           }
                           else if (length(male)%%length(female) ==
                                    1) {
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: The number of males is not divisible by the number of females."),
                                                      styleclass = "danger")
                           }
                           else if (length(female)%%length(male) ==
                                    1) {
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR:Number of females must be proportional to number of males."),
                                                      styleclass = "danger")
                           }
                           else if ((length(female)/length(male)) ==
                                    1) {
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR:The number of females must be at least 2 per male and you just got 1."),
                                                      styleclass = "danger")
                           }
                           else if (length(female)%%set * length(male) ==
                                    1) {
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR:The number of females, males and sets is not proportional,"),
                                                      styleclass = "danger")
                           }
                           else {
                             flag <- TRUE
                           }
                         }
                         if (input$design_geneticFieldbook == "NCII") {
                           if (input$fbdesign_gentemp == TRUE) {
                             male <- mtl_table$Accession_Number_Female
                             female <- mtl_table$Accession_Number_Male
                           }
                           else {
                             male <- mtl_table$Male_AcceNumb
                             female <- mtl_table$Female_AcceNumb
                           }
                           set <- as.numeric(input$design_genetic_nc_set)
                           r <- as.numeric(input$design_genetic_r)
                           print(male)
                           print(female)
                           if (length(male) != length(female)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: The length of males and females must be the same dimension"),
                                                      styleclass = "danger")
                           }
                           else if (r == 1 || is.na(r)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: You have entered just 1 replication or NA/NULL values."),
                                                      styleclass = "danger")
                           }
                           else if (is.null(male) || is.na(male)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: At minimimun 1 males"),
                                                      styleclass = "danger")
                           }
                           else if (length(female) == 1 || is.null(female) ||
                                    is.na(female)) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: At minimimun 1 females"),
                                                      styleclass = "danger")
                           }
                           else if (length(female)%%set != 0) {
                             flag <- FALSE
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERROR: data length is not a multiple of set variable. Please provide an accurate number of sets"),
                                                      styleclass = "danger")
                           }
                           else if (length(male)%%set == 1) {
                             shinysky::showshinyalert(session, "alert_fb_done",
                                                      paste("ERRO: It is not possible divide the number of males per the number of set."),
                                                      styleclass = "danger")
                           }
                           else {
                             flag <- TRUE
                           }
                         }
                       }
                       if (file.exists(fp)) {
                         shinysky::showshinyalert(session, "alert_fb_done",
                                                  paste("WARNING: This fieldbook already exists in HiDAP. Please Select Experiment Number in Crop & Location"),
                                                  styleclass = "warning")
                         flag <- FALSE
                       }
                       if (!file.exists(fp) && flag == TRUE) {
                         saveRDS(fb, fp)
                         values[["ph_fb_list"]] = NULL
                         shinysky::showshinyalert(session, "alert_fb_done",
                                                  paste("GREAT: Fieldbook successfully created!"),
                                                  styleclass = "success")
                         xlsx_path <- fbglobal::get_base_dir()
                         xlsx_path <- file.path(xlsx_path, fbdesign_id())
                         fn_xlsx <- paste(xlsx_path, ".xlsx", sep = "")
                         openxlsx::write.xlsx(fb, fn_xlsx, sheet = "Fieldbook",
                                              overwrite = TRUE)
                         add_fieldbook_sheet(file = fn_xlsx, fieldbook = fb)
                         crop_template <- crop_template_xlsx
                         combine <- input$designFieldbook_combfactor
                         print("2")
                         incProgress(2/15)
                         add_varlist_sheet(file = fn_xlsx, crop_template = crop_template,
                                           crop = input$designFieldbook_crop, trait_list = input$designFieldbook_traits)
                         incProgress(4/15)
                         add_minimal_sheet(file = fn_xlsx, crop_template = crop_template,
                                           col_name = "Value", Trial_name = fbdesign_id(),
                                           crop = input$designFieldbook_crop, type_trial = input$designFieldbook_module,
                                           begin_date = begin_date1, end_date = end_date1,
                                           site_short_name = input$designFieldbook_sites,
                                           country = input$fbDesign_countryTrial)
                         if (input$fbDesign_environment_type != "Field") {
                           n_plant_pot <- input$fbDesign_nplantxpot
                           n_pots <- input$fbDesign_npots
                           n_plot_row <- NA
                           n_plant_plot <- NA
                           n_plant_row <- NA
                           plot_size <- NA
                           plant_density <- NA
                           distance_plants <- NA
                           distance_rows <- NA
                         }
                         else {
                           n_plant_pot <- NA
                           n_pots <- NA
                           n_plot_row <- input$fbDesign_nrowplot
                           n_plant_plot <- input$fbDesign_nplants
                           n_plant_row <- input$fbDesign_nplantsrow
                           plot_size <- input$fbDesign_psize
                           plant_density <- input$fbDesign_pdensity
                           distance_plants <- input$fbDesign_distPlants
                           distance_rows <- input$fbDesign_distRows
                         }
                         print("3")
                         incProgress(3/15)
                         add_installation_sheet(file = fn_xlsx, crop_template = crop_template,
                                                col_name = "Value", exp_design = input$designFieldbook,
                                                genetic_design = genetic_design, type_of_ploidy = type_of_ploidy,
                                                set = set, r = r, block = NA, exp_env = input$fbDesign_environment_type,
                                                plot_start_number = NA, n_plant_pot = n_plant_pot,
                                                n_pots = n_pots, n_plot_row = n_plot_row,
                                                n_plant_plot = n_plant_plot, n_plant_row = n_plant_row,
                                                plot_size = plot_size, plant_density = plant_density,
                                                distance_plants = distance_plants, distance_rows = distance_rows,
                                                factor_name = factor_input, factor_lvl = flevel_input,
                                                combine = combine)
                         print("4")
                         incProgress(4/15)
                         add_metadata_sheet(file = fn_xlsx, crop_template = crop_template,
                                            soil_input = input$fbDesign_soil_cb, weather_input = input$fbDesign_weather_cb)
                         print("5")
                         incProgress(5/15)
                         print(mtl_table)
                         if (is.list(mtl_table) && is.element("Accession_Number_Female",
                                                              names(mtl_table)) && is.element("Accession_Number_Male",
                                                                                              names(mtl_table))) {
                           n <- max(unlist(lapply(mtl_table, function(x) length(x))))
                           length(mtl_table$Accession_Number_Female) <- n
                           length(mtl_table$Accession_Number_Male) <- n
                           length(mtl_table$IDX) <- n
                           res <- cbind(mtl_table$IDX, mtl_table$Accession_Number_Female,
                                        mtl_table$Accession_Number_Male) %>%
                             as.data.frame(stringsAsFactors = FALSE)
                           names(res) <- names(mtl_table)
                           mtl_table <- res
                         }
                         add_material_sheet(file = fn_xlsx, crop_template = crop_template,
                                            crop = input$designFieldbook_crop, material_list = mtl_table)
                         print("6")
                         incProgress(6/15)
                         add_cmanagment_sheet(file = fn_xlsx, crop_template = crop_template,
                                              crop = input$designFieldbook_crop, trait_list = input$designFieldbook_traits)
                         print("11")
                         shell.exec(fn_xlsx)
                         incProgress(15/15)
                       }
                     })
                   })
    })
    output$fbDesign_mlistExport <- downloadHandler(filename = function() {
      paste("Material_List", ".xlsx", sep = "")
    }, content = function(file) {
      mt_list <- crop_template_xlsx$Material_List
      hs <- createStyle(fontColour = "#000000", fontSize = 12,
                        fontName = "Calibri", fgFill = "orange")
      openxlsx::write.xlsx(mt_list, file, headerStyle = hs,
                           sheetName = "Material_List", colWidths = "auto")
    })
    output$fbDesign_mlistExportGenTemp <- downloadHandler(filename = "Material_list_Parental.xlsx",
                                                          content = function(file) {
                                                            mtlist_parental <- material_list_parental
                                                            hs <- createStyle(fontColour = "#000000", fontSize = 12,
                                                                              fontName = "Calibri", fgFill = "orange")
                                                            openxlsx::write.xlsx(mtlist_parental, file, headerStyle = hs,
                                                                                 sheetName = "Material_List_Parental", colWidths = "auto")
                                                          }, contentType = "application/xlsx")
    output$fbdesigin_downloadFbAppData <- downloadHandler(filename = function() {
      paste("data-", Sys.Date(), ".csv", sep = "")
    }, content = function(con) {
      path <- fbglobal::get_base_dir()
      shiny::withProgress(message = "Downloading file", value = 0,
                          {
                            incProgress(1/6, detail = paste("Reading HIDAP data..."))
                            fb <- fbdraft()
                            year <- input$fbdesign_year_fbapp
                            country <- input$fbdesign_cntry_fbapp
                            abbr_user_val <- stringr::str_trim(input$fbdesign_abbruser_fbapp,
                                                               side = "both")
                            abbr_user_val <- stringr::str_replace(abbr_user_val,
                                                                  pattern = "[[:space:]]", replacement = "")
                            abbr_user_val <- toupper(abbr_user_val)
                            location <- input$fbdesign_location_fbapp
                            yearcountry <- paste(year, country, sep = "")
                            fbapp_id <- paste(yearcountry, abbr_user_val,
                                              location, sep = "-")
                            print(fbapp_id)
                            print(abbr_user_val)
                            if (fbapp_id == "") {
                              shinysky::showshinyalert(session, "alert_fb_done",
                                                       paste("Enter trial abbreviationr"), styleclass = "danger")
                            }
                            else if (abbr_user_val == "") {
                              shinysky::showshinyalert(session, "alert_fb_done",
                                                       paste("Enter 'trial abbreviation'"), styleclass = "danger")
                            }
                            else if (fbapp_id != "" && abbr_user_val != "") {
                              print("paso")
                              design <- stringr::str_trim(input$designFieldbook,
                                                          side = "both")
                              fb <- fb %>% dplyr::mutate(abbr_user = fbapp_id)
                              if (design == "UNDR") {
                                fb <- fb[, c("abbr_user", "PLOT", "REP",
                                             "INSTN")]
                                names(fb) <- c("abbr_user", "plot_number",
                                               "rep", "accession_name")
                                fb <- fb %>% tidyr::unite_("plot_name", c("abbr_user",
                                                                          "plot_number"), sep = "", remove = FALSE)
                              }
                              else if (design == "CRD") {
                                fb <- fb[, c("abbr_user", "PLOT", "REP",
                                             "INSTN")]
                                names(fb) <- c("abbr_user", "plot_number",
                                               "rep", "accession_name")
                                fb <- fb %>% tidyr::unite_("plot_name", c("abbr_user",
                                                                          "plot_number"), sep = "", remove = FALSE)
                              }
                              else if (design == "RCBD") {
                                fb <- fb[, c("abbr_user", "PLOT", "REP",
                                             "INSTN")]
                                names(fb) <- c("abbr_user", "plot_number",
                                               "rep", "accession_name")
                                fb <- fb %>% tidyr::unite_("plot_name", c("abbr_user",
                                                                          "plot_number"), sep = "", remove = FALSE)
                              }
                              else if (design == "WD") {
                                fb <- fb[, c("abbr_user", "PLOT", "ROW",
                                             "COLUMN", "INSTN")]
                                names(fb) <- c("abbr_user", "plot_number",
                                               "row", "column", "accession_name")
                                fb <- fb %>% tidyr::unite_("plot_name", c("abbr_user",
                                                                          "plot_number"), sep = "", remove = FALSE)
                              }
                              else if (design == "AD") {
                                fb <- fb[, c("abbr_user", "PLOT", "REP",
                                             "BLOCK", "INSTN")]
                                names(fb) <- c("abbr_user", "plot_number",
                                               "rep", "block", "accession_name")
                                fb <- fb %>% tidyr::unite_("plot_name", c("abbr_user",
                                                                          "plot_number"), sep = "", remove = FALSE)
                              }
                              else {
                                shinysky::showshinyalert(session, "alert_fb_done",
                                                         paste("This design is not available for the FieldBookApp format. It will be available soon."),
                                                         styleclass = "danger")
                                fb <- NULL
                              }
                              fb$abbr_user <- NULL
                              incProgress(3/6, detail = paste("Downloading FieldBookApp-SPBase file..."))
                              incProgress(4/6, detail = paste("Refreshing HIDAP..."))
                              Sys.sleep(3)
                              incProgress(5/6, detail = paste("Refreshing HIDAP..."))
                              write.csv(fb, con, row.names = FALSE)
                              incProgress(6/6, detail = paste("Refreshing HIDAP..."))
                              Sys.sleep(5)
                            }
                          })
    })
    observe({
      toggleState("fbdesigin_downloadFbAppData", stringr::str_trim(input$fbdesign_abbruser_fbapp,
                                                                   side = "both") != "")
    })
  }

