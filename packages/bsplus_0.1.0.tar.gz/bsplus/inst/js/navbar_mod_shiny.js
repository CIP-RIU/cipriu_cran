// find the navbar_nav element
var elem_navbar_nav = document.getElementsByClassName("navbar-nav")[0];

// append "navbar-right" to the class
elem_navbar_nav.className = elem_navbar_nav.className.concat(" navbar-right");

