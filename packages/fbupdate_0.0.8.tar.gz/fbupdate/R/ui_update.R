#' UI for traittools
#' Returns user friendly ui
#' @author Omar Benites
#' @param type type of UI element, deault is a tab in a shinydashboard
#' @param title display title name
#' @param name UI TabName
#' @importFrom shiny actionButton HTML br tabPanel observeEvent h2 icon
#' @importFrom shinydashboard box tabBox tabItem
#' @importFrom rhandsontable rHandsontableOutput renderRHandsontable 
#' @importFrom shinyjs useShinyjs
#' @export

fbupdate_ui <- function(type="tab", title="Update Packages", name="update_packages") {       
  
  jscode <- "shinyjs.refresh = function() { history.go(0); }"
  #begin data_processing tabItem
  shinydashboard::tabItem(tabName = name,
                          h2(title),   
                          
                          useShinyjs(),
                          extendShinyjs(text = jscode),
                          
                          box(
                            title = " ", status = "primary", solidHeader = TRUE,
                            collapsible = TRUE, width = NULL,
                            
                            # try(shinyFiles::shinyFilesButton('file', 'File select', 'Please select a file',FALSE)),
                            shiny::actionButton("fbupdate_btnCheck", "Check Updates",icon("check-square")),
                            shiny::actionButton("fbupdate_btnUpdate", "Update Packages",icon("spinner")),
                            #shiny::actionButton("fbupdate_btnRefresh", "Refresh HiDAP",icon("refresh")),
                            HTML('<div style="float: right; margin: 0 5px 5px 10px;">'),
                            #shiny::actionLink('exportButton', 'Download data'),
                            HTML('</div>'),
                            
                            br(),
                            br(),  
                            
                            #tabsetPanel(
                            tabBox(width = 12,
                                   tabPanel("Table of Packages", #begin tabset "CHECK"
                                            #                                      fluidRow(
                                            #                                        shinyFiles::shinyFilesButton('file', 'File select', 'Please select a file',FALSE),
                                            #                                        shiny::actionButton("calculate", "Calculate",icon("play-circle-o")),
                                            #                                        HTML('<div style="float: right; margin: 0 5px 5px 10px;">'),
                                            #                                        shiny::actionLink('exportButton', 'Download data'),
                                            #                                        HTML('</div>'),
                                            
                                            shinysky::shinyalert("alert_fbupdate_done", FALSE, auto.close.after = 8),
                                            
                                            
                                            shinysky::shinyalert("alert_fbupdate_closehidap", FALSE, auto.close.after = 10),
                                            
                                            box(rHandsontableOutput("hot_table_checkpkg",height = "1400px",width = "1000px"),
                                                height = "3400px",width ="2400px")#,
                                            #                                      ),
                                            
                                              
                                            
                                            # tags$style(type='text/css', "#file { width:150px; margin-top: 25px;}"),
                                            # tags$style(HTML('#file {background-color:#0099cc; color: #ffffff}')),  
                                            # tags$style(type='text/css', "#calculate { width:150px; margin-top: 25px;}"),
                                            # tags$style(HTML('#calculate {background-color:#21b073; color: #ffffff}'))
                                            
                                   )#,
                                   
                                   #,#end tab Panel "CHECK"
                                   
                                   
                                   #### Hiden Special Modules during September Preview Release -----------------
                                   
                                   # 
                                   # tabPanel("Special Modules", #begin Trait List Panel"
                                   #          # fluidRow(
                                   #          #   shinydashboard::tabBox(
                                   #          #     title = "PVS",
                                   #          #     # The id lets us use input$tabset1 on the server to find the current tab
                                   #          #     
                                   #          #     id = "tabset1", width = "2400px",
                                   #          #     
                                   #          #    
                                   #          #     
                                   #          #   )
                                   #          # )
                                   #          #                                      fluidRow(
                                   #          #                                        box(rHandsontableOutput("hot_td_trait",height = "1400px",width = "1400px"),
                                   #          #                                            height = "3400px",width ="2400px")
                                   #          #                                      )#end fluidRow
                                   # )
                                   
                                   #### Hiden Special Modules during September Preview Release -----------------
                                   
                                   
                            )
                          ),
                          br(),
                          br(),
                          br()
                          
                          
  )#End data_processing tabItem
  
}

