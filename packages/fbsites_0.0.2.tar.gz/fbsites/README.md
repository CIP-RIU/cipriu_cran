[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/<USERNAME>/<REPO>?branch=master&svg=true)](https://ci.appveyor.com/project/<USERNAME>/<REPO>)

[![CRAN\_Status\_Badge](http://www.r-pkg.org/badges/version/fbsites)](http://cran.r-project.org/package=fbsites)

[![Coverage Status](https://img.shields.io/coveralls/<USERNAME>/<REPO>.svg)](https://coveralls.io/r/<USERNAME>/<REPO>?branch=master)

[![Coverage Status](https://img.shields.io/codecov/c/github/<USERNAME>/<REPO>/master.svg)](https://codecov.io/github/<USERNAME>/<REPO>?branch=master)
