#'Formula for calculating the Dry matter root  yield (DMRY)
#'
#'@param crw Commercial root weight
#'@param ncrw Non commercial root weight
#'@param rytha Root yield 
#'@param dm dry matter.
#'@param dmf Fresh weight of roots for dry matter assessment.
#'@param dmd Dry weight of dmf samples
#'@param pls Net plot size
#'@return Return the Dry matter root yield 'dmry' 
#'@author Omar Benites
#'@details Formula for calculating dry matter root yield
#'@keywords sweetpotato, agronomy,harvest,quantitative-continuous,yield
#'@family sweetpotato,quality,harvest
#'@export 
#'  
dmry <- function(crw= NULL,ncrw= NULL,rytha = NULL,dm = NULL,dmd= NULL,dmf= NULL, pls= NULL){
  
  if(is.null(pls)){
  #stop("Please enter the net plot size 'pls'")
    dmry <- rep(NA, length(crw))
  }
  if(is.null(dmd)){
  #stop("Please enter the dry matter root yield 'dmd")
    dmry <-  NA
  }
  if(is.null(dmf)){
  #stop("Please enter the Fresh weight of roots for dry matter assessment 'dmf")
    dmry <- NA
  }
  if(is.null(dm)){
    #stop("Please enter the Fresh weight of roots for dry matter assessment 'dmf")
    dmry <- NA
  } 
  if(!is.null(crw) && missing(ncrw))   {dmry <- (crw*10)/pls*dmd/dmf  }  
  if(is.null(crw)  && !is.null(ncrw))  {dmry <- (ncrw*10)/pls*dmd/dmf }       
  if(!is.null(crw) && !is.null(ncrw))  {dmry <- apply(cbind(crw, ncrw), 1, sbsum)*10/pls*dmd/dmf }
  if(!is.null(crw) && !is.null(ncrw))  {dmry <- apply(cbind(crw, ncrw), 1, sbsum)*dm/100 }
  if(!is.null(rytha) && !is.null(dm))  {dmry <- rytha*dm/100}
  return(dmry)
}
