# hidap 1.0.2.9001

* English edits in dependencies


# hidap 1.0.1.9014

* Added README.Rmd

# hidap 1.0.1.9013

* Added correct versioning
* English editing

# hidap 0.1.0.9011

* Added a `NEWS.md` file to track changes to the package.

