library(testthat)
library(fbanalysis)

test_check("fbanalysis")
